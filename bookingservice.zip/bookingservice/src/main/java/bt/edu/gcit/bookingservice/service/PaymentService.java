package bt.edu.gcit.bookingservice.service;

import bt.edu.gcit.bookingservice.entity.Payment;

public interface PaymentService {
    String initiateStripePayment(Long bookingId);
    void processSuccessfulPayment(Long bookingId);
}
