package bt.edu.gcit.bookingservice.controller;

import bt.edu.gcit.bookingservice.entity.Booking;
import bt.edu.gcit.bookingservice.entity.Payment;
import bt.edu.gcit.bookingservice.service.BookingService;
import bt.edu.gcit.bookingservice.dao.BookingRepository;
import bt.edu.gcit.bookingservice.dao.PaymentRepository;
import bt.edu.gcit.bookingservice.dao.RoomDao;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final BookingRepository bookingRepository;
    private final RestTemplate restTemplate;
    private final PaymentRepository paymentRepository;

    public PaymentController(
        BookingRepository bookingRepository,
        RestTemplate restTemplate,
        PaymentRepository paymentRepository
    ) {
        this.bookingRepository = bookingRepository;
        this.restTemplate = restTemplate;
        this.paymentRepository = paymentRepository;
    }

    // ✅ New endpoint for frontend-driven payment success confirmation
    // @PostMapping("/success")
    @PostMapping(value = "/success", consumes = "application/json")
    public ResponseEntity<String> markPaymentSuccess(@RequestBody Map<String, Object> payload) {
        Long bookingId = Long.parseLong(payload.get("bookingId").toString());

        Booking booking = bookingRepository.findById(bookingId).orElse(null);
        if (booking == null) {
            return ResponseEntity.badRequest().body("Invalid booking ID");
        }

        // 1. Update booking status
        booking.setStatus(Booking.BookingStatus.CONFIRMED);
        booking.setPaymentConfirmed(true);
        bookingRepository.save(booking);

        // 2. Save payment (dummy, as no real Stripe payment ID)
        Payment payment = new Payment();
        payment.setBookingId(bookingId);
        payment.setTransactionId("frontend-confirmed"); // Placeholder
        payment.setPaymentMethod("CARD");
        payment.setPaymentDate(LocalDateTime.now());
        payment.setSuccess(true);
        paymentRepository.save(payment);

        // 3. Set room unavailable via Room microservice
 Long roomId = booking.getRoomId();
    String roomUrl = "http://USERMICROSERVICE/api/rooms/" + roomId + "/availability";

    // Create JSON body for PUT request
    Map<String, String> availabilityPayload = Map.of("availabilityStatus", "BOOKED");

    try {
        restTemplate.put(roomUrl, availabilityPayload);
    } catch (Exception e) {
        return ResponseEntity.status(500).body("Payment saved, but failed to update room status: " + e.getMessage());
    }

        return ResponseEntity.ok("Payment confirmed and booking updated.");
    }
}
