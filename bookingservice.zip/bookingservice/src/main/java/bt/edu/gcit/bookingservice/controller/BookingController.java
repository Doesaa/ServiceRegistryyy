package bt.edu.gcit.bookingservice.controller;

import bt.edu.gcit.bookingservice.dao.BookingRequest;
import bt.edu.gcit.bookingservice.entity.Booking;
import bt.edu.gcit.bookingservice.service.BookingService;
import bt.edu.gcit.bookingservice.service.PaymentService;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;
    
    @Autowired
    private PaymentService paymentService;

    @PostMapping("/bookroom")
    public ResponseEntity<?> createBooking(@RequestBody BookingRequest request) {
        // 1. Create booking with PENDING status
        Booking booking = bookingService.createBooking(request);

        // 2. Generate Stripe Checkout URL for payment  
        String paymentUrl = paymentService.initiateStripePayment(booking.getId());

        // 3. Return the payment URL to the frontend
        return ResponseEntity.ok(Map.of(
                "bookingId", booking.getId(),
                "paymentUrl", paymentUrl
        ));
    }

    @GetMapping("/{id}")
    public Booking getBooking(@PathVariable Long id) {
        return bookingService.getBookingById(id);
    }

    @PutMapping("/confirm/{bookingId}")
    public ResponseEntity<String> confirmBooking(@PathVariable Long bookingId) {
        bookingService.confirmBooking(bookingId);
        return ResponseEntity.ok("Booking confirmed successfully.");
    }

    @GetMapping("/users/{userId}")
    public ResponseEntity<?> getBookingsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(bookingService.getBookingsByUserId(userId));
    }

}
