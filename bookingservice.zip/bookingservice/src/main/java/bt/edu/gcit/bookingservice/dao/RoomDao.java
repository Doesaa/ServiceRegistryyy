package bt.edu.gcit.bookingservice.dao;

import java.math.BigDecimal;

public class RoomDao {
    private Long id;
    private String availabilityStatus;
    private BigDecimal pricePerNight;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getAvailabilityStatus() { return availabilityStatus; }
    public void setAvailabilityStatus(String availabilityStatus) { this.availabilityStatus = availabilityStatus; }

    public BigDecimal getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(BigDecimal pricePerNight) { this.pricePerNight = pricePerNight; }
}
