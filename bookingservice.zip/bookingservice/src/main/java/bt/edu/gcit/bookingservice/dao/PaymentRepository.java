package bt.edu.gcit.bookingservice.dao;

import bt.edu.gcit.bookingservice.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
