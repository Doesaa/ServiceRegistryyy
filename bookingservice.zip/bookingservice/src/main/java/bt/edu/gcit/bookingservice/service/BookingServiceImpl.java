package bt.edu.gcit.bookingservice.service;

import bt.edu.gcit.bookingservice.dao.BookingRepository;
import bt.edu.gcit.bookingservice.dao.BookingRequest;
import bt.edu.gcit.bookingservice.dao.RoomDao;
import bt.edu.gcit.bookingservice.entity.Booking;
import bt.edu.gcit.bookingservice.entity.Booking.BookingStatus;
import bt.edu.gcit.bookingservice.dao.RoomDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public Booking createBooking(BookingRequest request) {
        // Fetch room info from USERMICROSERVICE
        // Do NOT use localhost:8765 here
       // Do NOT use localhost:8765 here
        RoomDao room = restTemplate.getForObject(
            "http://USERMICROSERVICE/api/rooms/{roomId}",
            RoomDao.class,
            request.getRoomId()
        );


        if (room == null || !"AVAILABLE".equals(room.getAvailabilityStatus())) {
            throw new RuntimeException("Room is not available.");
        }

        long days = ChronoUnit.DAYS.between(request.getCheckInDate(), request.getCheckOutDate());
        BigDecimal totalPrice = room.getPricePerNight().multiply(BigDecimal.valueOf(days));


        Booking booking = new Booking();
        booking.setUserId(request.getUserId());
        booking.setRoomId(request.getRoomId());
        booking.setCheckInDate(request.getCheckInDate());
        booking.setCheckOutDate(request.getCheckOutDate());
        booking.setStatus(BookingStatus.PENDING);
        booking.setPricePerNight(room.getPricePerNight());
        booking.setPaymentConfirmed(false);
        booking.setTotalPrice(totalPrice);


        bookingRepository.save(booking);

        // Set room status to PENDING in USERMICROSERVICE
        room.setAvailabilityStatus("PENDING");
        // restTemplate.put("http://USERMICROSERVICE/api/rooms/{userid}" + room.getId(), room);

        return booking;
    }

    @Override
    public Booking getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId)
            .orElseThrow(() -> new RuntimeException("Booking not found"));
    }


    @Override
    public Booking confirmBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (!booking.isPaymentConfirmed()) {
            throw new RuntimeException("Payment not confirmed. Cannot confirm booking.");
        }

        booking.setStatus(BookingStatus.CONFIRMED);

        restTemplate.put("http://USERMICROSERVICE/api/rooms/{roomId}/unavailable", null, booking.getRoomId());

        return bookingRepository.save(booking);

    }

    @Override
    public List<Booking> getBookingsByUserId(Long userId) {
        return bookingRepository.findByUserId(userId);
    }



}
