package bt.edu.gcit.bookingservice.service;

import bt.edu.gcit.bookingservice.dao.PaymentRepository;
import bt.edu.gcit.bookingservice.entity.Booking;
import bt.edu.gcit.bookingservice.entity.Payment;
import bt.edu.gcit.bookingservice.dao.BookingRepository;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingService bookingService;



    @Value("${stripe.secret.key}")
    private String stripeSecretKey;

    @Override
    public String initiateStripePayment(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        long days = ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());

        BigDecimal pricePerNight = booking.getPricePerNight();
        long amount = pricePerNight
                .multiply(BigDecimal.valueOf(days))
                .multiply(BigDecimal.valueOf(100)) // convert to cents
                .longValue();

        Stripe.apiKey = stripeSecretKey;

        try {
            SessionCreateParams params = SessionCreateParams.builder()
                    .setMode(SessionCreateParams.Mode.PAYMENT)
                    .setSuccessUrl("http://localhost:3000/success?bookingId=" + bookingId)
                    .setCancelUrl("http://localhost:3000/cancel")
                    .addLineItem(
                            SessionCreateParams.LineItem.builder()
                                    .setQuantity(1L)
                                    .setPriceData(
                                            SessionCreateParams.LineItem.PriceData.builder()
                                                    .setCurrency("usd")
                                                    .setUnitAmount(amount)
                                                    .setProductData(
                                                            SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                                    .setName("Room Booking")
                                                                    .build()
                                                    )
                                                    .build()
                                    )
                                    .build()
                    )
                    .build();

            Session session = Session.create(params);
            return session.getUrl();

        } catch (Exception e) {
            throw new RuntimeException("Stripe payment session creation failed: " + e.getMessage(), e);
        }
    }

        @Override
        public void processSuccessfulPayment(Long bookingId) {
                Booking booking = bookingRepository.findById(bookingId)
                        .orElseThrow(() -> new RuntimeException("Booking not found"));

                booking.setPaymentConfirmed(true);
                bookingRepository.save(booking);

                bookingService.confirmBooking(bookingId); // ✅ now this will work
        }
}
