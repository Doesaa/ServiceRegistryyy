package bt.edu.gcit.bookingservice.service;

import bt.edu.gcit.bookingservice.dao.BookingRequest;
import bt.edu.gcit.bookingservice.entity.Booking;
import java.time.LocalDate;
import java.util.List;

public interface BookingService {
    Booking createBooking(BookingRequest request);
    Booking getBookingById(Long bookingId);
    Booking confirmBooking(Long bookingId);
    List<Booking> getBookingsByUserId(Long userId);

}
